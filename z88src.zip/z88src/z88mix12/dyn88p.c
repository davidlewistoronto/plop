/***********************************************************************
* 
*               *****   ***    ***
*                  *   *   *  *   *
*                 *     ***    ***
*                *     *   *  *   *
*               *****   ***    ***
*
* A FREE Finite Elements Analysis Program in ANSI C for the UNIX OS.
*
* Composed and edited and copyright by 
* Professor Dr.-Ing. Frank Rieg, University of Bayreuth, Germany
*
* eMail: 
* frank.rieg@uni-bayreuth.de
* dr.frank.rieg@t-online.de
* 
* V12.0  February 14, 2005
*
* Z88 should compile and run under any UNIX OS and Motif 2.0.
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; see the file COPYING.  If not, write to
* the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
***********************************************************************/ 
/***********************************************************************
*  function dyn88p
*  4.10.2005 Rieg
***********************************************************************/ 

/***********************************************************************
* Fuer UNIX
***********************************************************************/
#ifdef FR_UNIX
#include <z88p.h>
#include <Xm/XmAll.h>/* XtCalloc */
#include <stdio.h>   /* fopen,fclose,fgets,fprintf,sscanf */
#include <string.h>  /* strstr */
#include <stdlib.h>  /* FR_CALLOC */
#endif

/***********************************************************************
* Windows95 und NT
***********************************************************************/
#ifdef FR_WIN95
#include <z88p.h>
#include <stdio.h>   /* fopen,fclose,fgets,fprintf,sscanf */
#include <string.h>  /* strstr */
#include <stdlib.h>  /* FR_CALLOC */
#endif

/***********************************************************************
* Functions
***********************************************************************/
int wlog88p(FR_INT4,int);

/***********************************************************************
* dyn88p
***********************************************************************/
int dyn88p(void)
{
extern FILE *fdyn, *fwlo;
extern char cdyn[];

extern FR_DOUBLEAY x;
extern FR_DOUBLEAY y;
extern FR_DOUBLEAY z;
extern FR_DOUBLEAY ux;
extern FR_DOUBLEAY uy;
extern FR_DOUBLEAY uz;
extern FR_DOUBLEAY xgp;
extern FR_DOUBLEAY ygp;
extern FR_DOUBLEAY zgp;
extern FR_DOUBLEAY siggp;

extern FR_INT4AY ityp;
extern FR_INT4AY koffs;
extern FR_INT4AY koi;
extern FR_INT4AY kx;
extern FR_INT4AY ky;
extern FR_INT4AY kgpx;
extern FR_INT4AY kgpy;

extern FR_INT4 MAXKOI,MAXE,MAXK,MFACCOMMON,MAXGP;
extern FR_INT4 IDYNMEM;

char cline[256], cdummy[80];
  
/*----------------------------------------------------------------------
* Dyn- datei z88.dyn oeffnen
*---------------------------------------------------------------------*/
wlog88p(0,LOG_OPENDYN);
fdyn= fopen(cdyn,"r");
if(fdyn == NULL)
  {
  wlog88p(0,LOG_NODYN);
  fclose(fwlo);
  return(AL_NODYN);
  }
rewind(fdyn);

/*----------------------------------------------------------------------
* Dyn- datei z88.dyn lesen
*---------------------------------------------------------------------*/
fgets(cline,256,fdyn);

if( (strstr(cline,"DYNAMIC START"))!= NULL)         /* Lesen File */
  {
  do
    {
    fgets(cline,256,fdyn);

    if( (strstr(cline,"COMMON START"))!= NULL)      /* Lesen COMMON */
      {
      do
        {
        fgets(cline,256,fdyn);
        if( (strstr(cline,"MAXKOI"))!= NULL)        /* Lesen MAXKOI */
          sscanf(cline,"%s %ld",cdummy,&MAXKOI);
        if( (strstr(cline,"MAXE"))!= NULL)          /* Lesen MAXE */
          sscanf(cline,"%s %ld",cdummy,&MAXE);
        if( (strstr(cline,"MAXK"))!= NULL)          /* Lesen MAXK */
          sscanf(cline,"%s %ld",cdummy,&MAXK);
        }
      while( (strstr(cline,"COMMON END"))== NULL);
      }

    if( (strstr(cline,"PLOT START"))!= NULL)        /* Lesen PLOT */
      {
      do
        {
        fgets(cline,256,fdyn);
        if( (strstr(cline,"MFACCOMMON"))!= NULL)    /* Lesen MFACCOMMON */
          sscanf(cline,"%s %ld",cdummy,&MFACCOMMON);
        if( (strstr(cline,"MAXGP"))!= NULL)         /* Lesen MAXGP */
          sscanf(cline,"%s %ld",cdummy,&MAXGP);
        }
      while( (strstr(cline,"PLOT END"))== NULL);
      }                                             /* end if PLOT START */

    }
  while( (strstr(cline,"DYNAMIC END"))== NULL);     
    
  }                                                 /* end if DYNAMIC START */
else
  {
  wlog88p(0,LOG_WRONGDYN);
  fclose(fwlo);
  return(AL_WRONGDYN);
  }  

if(MAXKOI <= 0 || MAXE <= 0 || MAXK <= 0 || MFACCOMMON <= 0 || MAXGP <= 0)
  {
  wlog88p(0,LOG_WRONGDYN);
  fclose(fwlo);
  return(AL_WRONGDYN);
  }  

/*----------------------------------------------------------------------
* korrekt gelesen, file fdyn schliessen
*---------------------------------------------------------------------*/
fclose(fdyn);

/*----------------------------------------------------------------------
* Common-werte ggf. vervielfachen
*---------------------------------------------------------------------*/
MAXKOI *= MFACCOMMON;
MAXK   *= MFACCOMMON;
MAXE   *= MFACCOMMON;

wlog88p(MAXKOI,LOG_MAXKOI);
wlog88p(MAXE,LOG_MAXE);
wlog88p(MAXK,LOG_MAXK);
wlog88p(MFACCOMMON,LOG_MFACCOMMON);
wlog88p(MAXGP,LOG_MAXGP);

wlog88p(0,LOG_OKDYN);

/*----------------------------------------------------------------------
* Memory kommen lassen ..
*---------------------------------------------------------------------*/
wlog88p(0,LOG_ALLOCMEMY);

/*======================================================================
* Memory fuer x, y, z: 1,2,3
*=====================================================================*/
x= (FR_DOUBLEAY) FR_CALLOC(MAXK,sizeof(FR_DOUBLE));
if(x == NULL)
  {
  wlog88p(1,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(1,LOG_ARRAYOK);

y= (FR_DOUBLEAY) FR_CALLOC(MAXK,sizeof(FR_DOUBLE));
if(y == NULL)
  {
  wlog88p(2,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(2,LOG_ARRAYOK);

z= (FR_DOUBLEAY) FR_CALLOC(MAXK,sizeof(FR_DOUBLE));
if(z == NULL)
  {
  wlog88p(3,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(3,LOG_ARRAYOK);

/*======================================================================
* Memory fuer ux, uy, uz: 4,5,6
*=====================================================================*/
ux= (FR_DOUBLEAY) FR_CALLOC(MAXK,sizeof(FR_DOUBLE));
if(ux == NULL)
  {
  wlog88p(4,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(4,LOG_ARRAYOK);

uy= (FR_DOUBLEAY) FR_CALLOC(MAXK,sizeof(FR_DOUBLE));
if(uy == NULL)
  {
  wlog88p(5,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(5,LOG_ARRAYOK);

uz= (FR_DOUBLEAY) FR_CALLOC(MAXK,sizeof(FR_DOUBLE));
if(uz == NULL)
  {
  wlog88p(6,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(6,LOG_ARRAYOK);

/*======================================================================
* Memory fuer xgp, ygp, zgp, siggp: 7,8,9,10
*=====================================================================*/
xgp= (FR_DOUBLEAY) FR_CALLOC(MAXGP,sizeof(FR_DOUBLE));
if(xgp == NULL)
  {
  wlog88p(7,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(7,LOG_ARRAYOK);

ygp= (FR_DOUBLEAY) FR_CALLOC(MAXGP,sizeof(FR_DOUBLE));
if(ygp == NULL)
  {
  wlog88p(8,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(8,LOG_ARRAYOK);

zgp= (FR_DOUBLEAY) FR_CALLOC(MAXGP,sizeof(FR_DOUBLE));
if(zgp == NULL)
  {
  wlog88p(9,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(9,LOG_ARRAYOK);

siggp= (FR_DOUBLEAY) FR_CALLOC(MAXGP,sizeof(FR_DOUBLE));
if(siggp == NULL)
  {
  wlog88p(10,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(10,LOG_ARRAYOK);

/*======================================================================
* Memory fuer ityp, koffs: 11,12
*=====================================================================*/
ityp= (FR_INT4AY) FR_CALLOC(MAXE,sizeof(FR_INT4));
if(ityp == NULL)
  {
  wlog88p(11,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(11,LOG_ARRAYOK);

koffs= (FR_INT4AY) FR_CALLOC(MAXE,sizeof(FR_INT4));
if(koffs == NULL)
  {
  wlog88p(12,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(12,LOG_ARRAYOK);

/*======================================================================
* Memory fuer koi: 13
*=====================================================================*/
koi= (FR_INT4AY) FR_CALLOC(MAXKOI,sizeof(FR_INT4));
if(koi == NULL)
  {
  wlog88p(13,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(13,LOG_ARRAYOK);

/*======================================================================
*  memory fuer kx, ky, kgpx, kgpy: 14,15,16,17
*=====================================================================*/
kx= (FR_INT4AY) FR_CALLOC(MAXK,sizeof(FR_INT4));
if(kx == NULL)
  {
  wlog88p(14,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(14,LOG_ARRAYOK);

ky= (FR_INT4AY) FR_CALLOC(MAXK,sizeof(FR_INT4));
if(ky == NULL)
  {
  wlog88p(15,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(15,LOG_ARRAYOK);

kgpx= (FR_INT4AY) FR_CALLOC(MAXGP,sizeof(FR_INT4));
if(kgpx == NULL)
  {
  wlog88p(16,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(16,LOG_ARRAYOK);

kgpy= (FR_INT4AY) FR_CALLOC(MAXGP,sizeof(FR_INT4));
if(kgpy == NULL)
  {
  wlog88p(17,LOG_ARRAYNOTOK);
  fclose(fwlo);
  return(AL_NOMEMY);
  }
else
  wlog88p(17,LOG_ARRAYOK);

/***********************************************************************
* alles o.k. 
***********************************************************************/
IDYNMEM = 3*MAXK*sizeof(FR_DOUBLE);              /* x,y,z */
IDYNMEM+= 3*MAXK*sizeof(FR_DOUBLE);              /* ux,uy,uz */
IDYNMEM+= 4*MAXGP*sizeof(FR_DOUBLE);             /* xgp,ygp,zgp,siggp */
IDYNMEM+= 2*MAXE*sizeof(FR_INT4);                /* ityp,koffs */  
IDYNMEM+=   MAXKOI *sizeof(FR_INT4);             /* koi */
IDYNMEM+= 2*MAXK*sizeof(FR_INT4);                /* kx,ky */
IDYNMEM+= 2*MAXGP*sizeof(FR_INT4);               /* kgpx,kgpy */

wlog88p(IDYNMEM,LOG_SUMMEMY);
wlog88p(0,LOG_EXITDYN88P);

return 0;
}
