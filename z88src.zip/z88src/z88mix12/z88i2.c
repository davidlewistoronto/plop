/***********************************************************************
* 
*               *****   ***    ***
*                  *   *   *  *   *
*                 *     ***    ***
*                *     *   *  *   *
*               *****   ***    ***
*
* A FREE Finite Elements Analysis Program in ANSI C for the Windows OS.
*
* Composed and edited and copyright by 
* Professor Dr.-Ing. Frank Rieg, University of Bayreuth, Germany
*
* eMail: 
* frank.rieg@uni-bayreuth.de
* dr.frank.rieg@t-online.de
* 
* V12.0  February 14, 2005
*
* Z88 should compile and run under any Windows release, starting
* with Windows95.
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2, or (at your option)
* any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; see the file COPYING.  If not, write to
* the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
***********************************************************************/ 
/****************************************************************************
*  Programm z88i2.c - der Iterations- Solver Part 2
*  23.8.2005 Rieg
****************************************************************************/

/***********************************************************************
* Windows95 und NT
***********************************************************************/
#ifdef FR_WIN95
#include <z88i.h>
#include <windows.h>
#include <commctrl.h>
#include <stdio.h>    /* FILE */
#include <string.h>   /* strcpy */
#endif

/***********************************************************************
*  Window- Function-Declarationen
***********************************************************************/
LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);

HWND InitToolBar   (HWND hParent);

HFONT EzCreateFont (HDC hdc, char * szFaceName, int iDeciPtHeight,
                    int iDeciPtWidth, int iAttributes, BOOL fLogRes);

/***********************************************************************
*  externe Variable
***********************************************************************/
HDC        hDC;
HINSTANCE  hInstance;
HFONT      hFont;

HWND       hToolBar;
HMENU      hMenuGer,hMenuEng;

HCURSOR    waitcur;

/***********************************************************************
*  Function-Declarationen
***********************************************************************/
int dyn88i2(void);
int ale88i(int);
int z88bi(void);
int z88ci(void);
int lan88i2(void);
int r1y88i(void);
int r4y88i(void);
int wlog88i2(FR_INT4,int);

/***********************************************************************
*  globale Variable
***********************************************************************/
/*--------------------------------------------------------------------------
* Files
*-------------------------------------------------------------------------*/
FILE *fdyn,*fl2,*fi2,*fi4,*fi5,*f1y,*f3y,*f4y,*fo1,*fo2,*fcfg;

/*  
**   fdyn= z88.dyn
**   fl2 = z88i2.log
**   fi2=  z88i2.txt
**   fi4=  z88i4.txt
**   fi5=  z88i5.txt
**   f1y=  z88o1.bny
**   f3y=  z88o3.bny
**   f4y=  z88o4.bny
**   fo1=  z88o1.txt
**   fo2=  z88o2.txt
**   fcfg= z88com.cfg
*/ 

char cdyn[1000];
char cl2[1000];
char ci2[1000];
char ci4[1000];
char ci5[1000];
char c1y[1000];
char c3y[1000];
char c4y[1000];
char co1[1000];
char co2[1000];
char cfg[1000];

#define cdyn_file_name "z88.dyn"
#define cl2_file_name "z88i2.log"
#define ci2_file_name "z88i2.txt"
#define ci4_file_name "z88i4.txt"
#define ci5_file_name "z88i5.txt"
#define c1y_file_name "z88o1.bny"
#define c3y_file_name "z88o3.bny"
#define c4y_file_name "z88o4.bny"
#define co1_file_name "z88o1.txt"
#define co2_file_name "z88o2.txt"
#define cfg_file_name "z88com.cfg"

/*--------------------------------------------------------------------------
* Pointer
*-------------------------------------------------------------------------*/
FR_DOUBLEAY GS;
FR_DOUBLEAY CI;
FR_DOUBLEAY se;
FR_DOUBLEAY rs;
FR_DOUBLEAY xi;
FR_DOUBLEAY xa;
FR_DOUBLEAY v;
FR_DOUBLEAY pk;
FR_DOUBLEAY zz;
FR_DOUBLEAY fak;
FR_DOUBLEAY x;
FR_DOUBLEAY y;
FR_DOUBLEAY z;
FR_DOUBLEAY emod;
FR_DOUBLEAY rnue;
FR_DOUBLEAY qpara;
FR_DOUBLEAY riyy;
FR_DOUBLEAY eyy;
FR_DOUBLEAY rizz;
FR_DOUBLEAY ezz;
FR_DOUBLEAY rit;
FR_DOUBLEAY wt;
FR_DOUBLEAY pres;
FR_DOUBLEAY tr1;
FR_DOUBLEAY tr2;

FR_INT4AY ip;
FR_INT4AY iez;
FR_INT4AY koi;
FR_INT4AY ifrei; 
FR_INT4AY ioffs;
FR_INT4AY koffs;
FR_INT4AY ityp;
FR_INT4AY ivon;
FR_INT4AY ibis;
FR_INT4AY intord;
FR_INT4AY nep;
FR_INT4AY noi;
FR_INT4AY noffs;

/*--------------------------------------------------------------------------
* Char-Arrays
*-------------------------------------------------------------------------*/
char cstore[256];
char cbcall[128];
char cbpref[128];
char cbhelp[512];
char cmess [256];

/*--------------------------------------------------------------------------
* Arrays
*-------------------------------------------------------------------------*/
FR_INT4 mcomp[21];                     /* 21 ist MAXPA */

/* Diese Arrays werden in HEXA88,LQUA88,QSHE88 und CSHE88 verwendet */

FR_DOUBLE xk[21], yk[21], zk[21];      /* 21 ist MAXPA , HEXA88 */
FR_DOUBLE h[21];                       /* 21 ist MAXPA , HEXA88 */
FR_DOUBLE b[361];                      /* ist 6 x 60 +1, HEXA88 */
FR_DOUBLE xx[61];                      /* ist 3 x 20 +1, HEXA88 */
FR_DOUBLE d[37];                       /* ist 6 x 6  +1, HEXA88 */
FR_DOUBLE p[61];                       /* ist 3 x 20 +1, HEXA88 */

/* fuer Plattenberechnung */
FR_DOUBLE be[49];                         /* fuer 16-Knoten Platte  */
FR_DOUBLE hi[49];
FR_DOUBLE hj[49];
FR_DOUBLE hk[49];
FR_DOUBLE bbi[145];
FR_DOUBLE bsv[97];
FR_DOUBLE dbi[10];
FR_DOUBLE dsv[5];

/*--------------------------------------------------------------------------
* Variable
*-------------------------------------------------------------------------*/
FR_DOUBLE  emode,rnuee,qparae,riyye,eyye,rizze,ezze,rite,wte,eps,rp;
FR_DOUBLE  pree,tr1e,tr2e;
FR_INT4    intore,nel,ktyp,maxit,kfoun,jelem;
FR_INT4    LANG,IDYNMEM,ICFLAG;
FR_INT4    ndim,nkp,ne,nfg,neg,nfgp1,nkoi,kflag,ibflag,ipflag,npr,iqflag;

/*--------------------------------------------------------------------------
* vorbelegte Variable
*-------------------------------------------------------------------------*/
FR_INT4    MAXGS=0,MAXNFG=0,MAXK=0,MAXE=0,MAXKOI=0,MAXNEG=0;
FR_INT4    MAXESM=3600,MAXPR=0;
int        ifmode= IDM_SOR;

/***********************************************************************
* WinMain
***********************************************************************/
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   PSTR lpszCmdLine, int nCmdShow)
{
HWND       hWnd;
MSG        msg;
WNDCLASSEX wndclass;

char       capname[10];
char *tmpenv;
char tmpname [1000];

/***********************************************************************
* Handles kommen lassen, window oeffnen
***********************************************************************/
strcpy(capname, "Z88I2");

#ifdef gui_plop_version
if ((tmpenv = getenv ("TEMP")) == NULL && (tmpenv = getenv ("TMP")) == NULL) {
	tmpname [0] = '\0';
} else {
	sprintf (tmpname, "%s\\", tmpenv);
}
#else
	tmpname [0] = '\0';
#endif

sprintf (cdyn, "%s", cdyn_file_name);
sprintf (cl2, "%s%s", tmpname, cl2_file_name);
sprintf (ci2, "%s%s", tmpname, ci2_file_name);
sprintf (ci4, "%s", ci4_file_name);
sprintf (ci5, "%s%s", tmpname, ci5_file_name);
sprintf (c1y, "%s%s", tmpname, c1y_file_name);
sprintf (c3y, "%s%s", tmpname, c3y_file_name);
sprintf (c4y, "%s%s", tmpname, c4y_file_name);
sprintf (co1, "%s%s", tmpname, co1_file_name);
sprintf (co2, "%s%s", tmpname, co2_file_name);
sprintf (cfg, "%s", cfg_file_name);

wndclass.cbSize        = sizeof(wndclass);
wndclass.style         = CS_HREDRAW | CS_VREDRAW;
wndclass.lpfnWndProc   = WndProc;
wndclass.cbClsExtra    = 0;
wndclass.cbWndExtra    = 0;
wndclass.hInstance     = hInstance;
wndclass.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(ICO_Z88I2));
wndclass.hCursor       = LoadCursor(NULL, IDC_ARROW);
/* wndclass.hbrBackground = (HBRUSH)(COLOR_WINDOW+1); */
wndclass.hbrBackground = CreateSolidBrush(RGB(255,0,0));
wndclass.lpszMenuName  = capname;
wndclass.lpszClassName = capname;
wndclass.hIconSm       = LoadIcon(hInstance, MAKEINTRESOURCE(ICO_Z88I2));

RegisterClassEx(&wndclass);

hWnd = CreateWindow(capname,"Z88 Iteration Solver Part 2 Z88I2",
                    WS_OVERLAPPEDWINDOW,
                    150,220,
                    550,360,
                    NULL, NULL, hInstance, NULL);

InitCommonControls();

ShowWindow(hWnd, nCmdShow);
UpdateWindow(hWnd);

while(GetMessage(&msg, NULL, 0, 0))
  {
  TranslateMessage(&msg);
  DispatchMessage(&msg);
  }

DeleteObject(hFont);

return msg.wParam;
}

/***********************************************************************
* Main Window Procedure
***********************************************************************/
LRESULT CALLBACK WndProc(HWND hWnd, UINT Message,
                         WPARAM wParam, LPARAM lParam)
{
extern HDC        hDC;
extern HINSTANCE  hInstance;
extern HFONT      hFont;

extern HWND       hToolBar;
extern HMENU      hMenuGer,hMenuEng;

extern HCURSOR    waitcur;

extern FR_INT4    ICFLAG,LANG;
extern int        ifmode;

extern char       cstore[];
extern char       cbcall[];
extern char       cbpref[];
extern char       cbhelp[];
extern char       cmess[];

HMENU             hMenu;

PAINTSTRUCT       ps;

static int        ixClient,iyClient;

int               imess,iret;

size_t            laenge;

/*----------------------------------------------------------------------
* Los gehts
*---------------------------------------------------------------------*/
switch (Message)
  {
/*----------------------------------------------------------------------
* case WM_CREATE
*---------------------------------------------------------------------*/
  case WM_CREATE:

/*======================================================================
* hInstance kommen lassen
*=====================================================================*/
    hInstance= (HINSTANCE)GetWindowLong(hWnd,GWL_HINSTANCE);

/*======================================================================
* Wartecursor anlegen
*=====================================================================*/
    waitcur= LoadCursor(hInstance,MAKEINTRESOURCE(CUR_Z88I2));

/*======================================================================
* Sprache feststellen
*=====================================================================*/
    iret= lan88i2();
    if(iret != 0)
      {
      ale88i(iret);
      PostQuitMessage(0);
      return(1);
      }

    hMenuGer= LoadMenu(hInstance,"GERMAN");
    hMenuEng= LoadMenu(hInstance,"ENGLISH");

    if(LANG == 1) SetMenu(hWnd,hMenuGer);
    if(LANG == 2) SetMenu(hWnd,hMenuEng);

/*===========================================================================
* ICFLAG setzen
*==========================================================================*/
    if(ifmode == IDM_SOR) ICFLAG = 2;

/*======================================================================
* Toolbar
*=====================================================================*/
    hToolBar= InitToolBar(hWnd);

  return 0; /* Ende WM_CREATE */

/*----------------------------------------------------------------------
* case WM_INITMENU
*---------------------------------------------------------------------*/
  case WM_INITMENU:
    hMenu= GetMenu(hWnd); /* muss rein */

    CheckMenuItem(hMenu,IDM_SIC, MF_UNCHECKED | MF_BYCOMMAND);   
    CheckMenuItem(hMenu,IDM_SOR, MF_UNCHECKED | MF_BYCOMMAND);   
    CheckMenuItem(hMenu,ifmode,  MF_CHECKED   | MF_BYCOMMAND);   
  return 0;
  
/*----------------------------------------------------------------------
* case WM_MOVE
*---------------------------------------------------------------------*/
  case WM_MOVE:
  return 0;

/*----------------------------------------------------------------------
* case WM_SIZE
*---------------------------------------------------------------------*/
  case WM_SIZE:
    iyClient= HIWORD(lParam);
    ixClient= LOWORD(lParam);
  return 0;

/*----------------------------------------------------------------------
* WM_NOTIFY
*---------------------------------------------------------------------*/
  case WM_NOTIFY:
    {
    LPNMHDR pnmh= (LPNMHDR) lParam;
    LPSTR   pReply;

    if(pnmh->code == TTN_NEEDTEXT)
      {
      LPTOOLTIPTEXT lpttt= (LPTOOLTIPTEXT) lParam;

      switch(lpttt->hdr.idFrom)
        {
        case ITC_GO:
          if(LANG == 1) pReply= "Berechne nun die Verformungen";
          if(LANG == 2) pReply= "Run the displacement calculation";
        break;

        case ITC_HELP:
          if(LANG == 1) pReply= "OnLine-Hilfe fuer Iterationssolver";
          if(LANG == 2) pReply= "OnLine Help for Iteration Solver";
        break;

        case ITC_SIC:
          if(LANG == 1)
            pReply= "Vorkonditionierung durch unvollst. Choleky- Zerlegung";
          if(LANG == 2)
            pReply= "Preconditioning by incomplete Choleky Decomposition";
        break;

        case ITC_SOR:
          if(LANG == 1)
            pReply= "Vorkonditionierung durch Ueberrelaxation";
          if(LANG == 2)
            pReply= "Preconditioning by Overrelaxation";
        break;

        }
      lstrcpy(lpttt->szText,pReply);
      }
    return 0;  /* sehr wichtig */
    }

/*----------------------------------------------------------------------
* case WM_COMMAND
*---------------------------------------------------------------------*/
  case WM_COMMAND:
    switch (LOWORD(wParam))
      {

/*======================================================================
* COMMAND : Wer ist es
*=====================================================================*/
      case IDM_WER:
        if(LANG == 1) strcpy(cmess,
"Der FE- Prozessor Z88I2 fuer Windows\n\
Version 12.0\n\
Der Iterationssolver Part 2\n\
Copyright Univ.-Prof.Dr.-Ing. Frank Rieg,\n\
Universitaet Bayreuth, 2005\n\
Alle Rechte vorbehalten");
          if(LANG == 2) strcpy(cmess,
"FEA Solver Z88I2 for Windows\n\
Version 12.0\n\
The Iteration Solver Part 2\n\
Copyright Prof.Dr. Frank Rieg,\n\
University of Bayreuth, Germany 2005\n\
All rights reserved");
        MessageBox(NULL,cmess,"Z88I2", MB_OK | MB_ICONINFORMATION);
      return 0;

/*======================================================================
* COMMAND : Xit
*=====================================================================*/
      case IDM_XIT:
        if(LANG == 1) strcpy(cmess,"Z88I2 beenden ?");
        if(LANG == 2) strcpy(cmess,"Quit Z88I2 ?");
        imess= MessageBox(NULL,cmess,"Z88I2",MB_OKCANCEL | MB_ICONQUESTION);
        if(imess == IDOK)     PostQuitMessage(0);
        if(imess == IDCANCEL) return 0;  
      return 0; 

/*======================================================================
* COMMAND : Hilfe
*=====================================================================*/
      case ITC_HELP:
        fcfg= fopen(cfg,"r");          /* Z88COM.CFG oeffnen */
        if(fcfg == NULL)
          {
          if(LANG == 1) strcpy(cmess,
          "Datei Z88COM.CFG nicht vorhanden oder zerschossen !");
          if(LANG == 2) strcpy(cmess,
          "File Z88COM.CFG not available or destroyed !");
          MessageBox(NULL,cmess,"Z88I2", MB_OK | MB_ICONHAND);
          }

        rewind(fcfg);

        fgets(cstore,128,fcfg);
        fgets(cstore,128,fcfg);

        fgets(cstore,128,fcfg);
        laenge= strlen(cstore);
        strncpy(cbpref,cstore,laenge-1);
        strcat (cbpref,"\0");

        fgets(cstore,128,fcfg);
        laenge= strlen(cstore);
        strncpy(cbcall,cstore,laenge-1);
        strcat (cbcall,"\0");

        fclose(fcfg); 

        strcpy(cbhelp,cbcall);
        strcat(cbhelp," ");
        strcat(cbhelp,cbpref);
        if(LANG == 1) strcat(cbhelp,"g88ite.htm");
        if(LANG == 2) strcat(cbhelp,"e88ite.htm");
        imess= WinExec(cbhelp,SW_SHOW);
        if(imess < 33)
          {
          if(LANG == 1) strcpy(cmess,
          "Internet Browser konnte nicht gestartet werden !");
          if(LANG == 2) strcpy(cmess,
          "Could not launch Internet Browser !");
          MessageBox(NULL,cmess,"Z88I2", MB_OK | MB_ICONHAND);
          }

      return 0;

/*======================================================================
* COMMAND : Mode aus Menue
*=====================================================================*/
      case IDM_SIC:
      case IDM_SOR:
        hMenu= GetMenu(hWnd);
        CheckMenuItem(hMenu,ifmode,MF_UNCHECKED | MF_BYCOMMAND);
        ifmode= LOWORD(wParam);
        CheckMenuItem(hMenu,ifmode,MF_CHECKED | MF_BYCOMMAND);   

        if     (ifmode == IDM_SIC) 
          {
          ICFLAG = 1;
          SendMessage(hToolBar,TB_CHECKBUTTON,
          (WPARAM)ITC_SIC,(LPARAM) MAKELONG(TRUE,0) );
          SendMessage(hToolBar,TB_CHECKBUTTON,
          (WPARAM)ITC_SOR,(LPARAM) MAKELONG(FALSE,0) );
          }

        else if(ifmode == IDM_SOR)
          {
          ICFLAG = 2;
          SendMessage(hToolBar,TB_CHECKBUTTON,
          (WPARAM)ITC_SIC,(LPARAM) MAKELONG(FALSE,0) );
          SendMessage(hToolBar,TB_CHECKBUTTON,
          (WPARAM)ITC_SOR,(LPARAM) MAKELONG(TRUE,0) );
          }

        else MessageBox(NULL,"No Mode !","Z88I2", MB_OK | MB_ICONHAND);
        InvalidateRect(hWnd,NULL,TRUE);
      return 0; 

/*======================================================================
* COMMAND : Mode aus Toolbar
*=====================================================================*/
      case ITC_SIC:
        ICFLAG = 1;
        ifmode = IDM_SIC; 
        InvalidateRect(hWnd,NULL,TRUE);
      return 0;

      case ITC_SOR:
        ICFLAG = 2;
        ifmode = IDM_SOR; 
        InvalidateRect(hWnd,NULL,TRUE);
      return 0;

/*======================================================================
* COMMAND : Go
*=====================================================================*/
      case IDM_GO:
      case ITC_GO:
        SetCursor(waitcur);
        ShowCursor(TRUE);
        
        hDC= GetDC(hWnd);
        hFont= EzCreateFont(hDC,"Times New Roman",120,0,2,TRUE);
        SelectObject(hDC,hFont);
        SetBkColor(hDC,RGB(255,0,0));

        if     (ICFLAG == 1) wlog88i2(1L,LOG_CFLAGC);
        else if(ICFLAG == 2) wlog88i2(2L,LOG_CFLAGS);
 
/*----------------------------------------------------------------------
* dynamischen Speicher anfordern: erst ab hier moeglich
*---------------------------------------------------------------------*/
    iret= dyn88i2();
    if(iret != 0) 
      { 
      ale88i(iret);
      PostQuitMessage(0);
      return 0;
      }           
     
/*----------------------------------------------------------------------
* Einlesen von Z88O1.BNY und Z88O4.BNY
*---------------------------------------------------------------------*/
        iret= r1y88i();
        if(iret != 0)
          {
          ale88i(iret);
          PostQuitMessage(0);
          return(0);
          }               

        iret= r4y88i();
        if(iret != 0)
          {
          ale88i(iret);
          PostQuitMessage(0);
          return(0);
          }                  
   
/*----------------------------------------------------------------------
* Rechnen
*---------------------------------------------------------------------*/
        iret= z88bi();
        if(iret != 0)
          {
          ale88i(iret);
          PostQuitMessage(0);
          return(0);
          }                

        iret= z88ci();
        if(iret != 0)
          {
          ale88i(iret);
          PostQuitMessage(0);
          return(0);
          }                   

/*----------------------------------------------------------------------
* den Speicher wieder freigeben; die UNIX- Version braucht das nicht
*---------------------------------------------------------------------*/
        if(GS)      free(GS);
        if(CI)      free(CI);
        if(se)      free(se);
        if(rs)      free(rs);
        if(xi)      free(xi);
        if(xa)      free(xa);
        if(v)       free(v);
        if(pk)      free(pk);
        if(zz)      free(zz);
        if(fak)     free(fak);
        if(x)       free(x);
        if(y)       free(y);
        if(z)       free(z);
        if(emod)    free(emod);
        if(rnue)    free(rnue);
        if(qpara)   free(qpara);
        if(riyy)    free(riyy);
        if(eyy)     free(eyy);
        if(rizz)    free(rizz);
        if(ezz)     free(ezz);
        if(rit)     free(rit);
        if(wt)      free(wt);
        if(pres)    free(pres);

        if(ip)      free(ip);
        if(iez)     free(iez);
        if(koi)     free(koi);
        if(ifrei)   free(ifrei);
        if(ioffs)   free(ioffs);
        if(koffs)   free(koffs);
        if(ityp)    free(ityp);
        if(ivon)    free(ivon);
        if(ibis)    free(ibis);
        if(intord)  free(intord);
        if(noi)     free(noi);
        if(noffs)   free(noffs);

/*----------------------------------------------------------------------
* Ende Case Go
*---------------------------------------------------------------------*/
        if(LANG == 1) strcpy(cmess,"FE-Prozessor Z88I2 gelaufen");
        if(LANG == 2) strcpy(cmess,"FEA-Solver Z88I2 done");
        MessageBox(NULL,cmess,"Z88I2", MB_OK | MB_ICONINFORMATION);
        ReleaseDC(hWnd,hDC);  
        SetCursor(LoadCursor(NULL,IDC_ARROW));
      return 0;                           /* end case GO */

      default:
        return DefWindowProc(hWnd, Message, wParam, lParam);
      }                                /* end switch command */ 

/*----------------------------------------------------------------------
* case WM_PAINT
*---------------------------------------------------------------------*/
  case WM_PAINT:
    memset(&ps, 0x00, sizeof(PAINTSTRUCT));
    hDC = BeginPaint(hWnd, &ps);

    SetBkMode(hDC, TRANSPARENT);

    EndPaint(hWnd, &ps);
  return 0;

/*----------------------------------------------------------------------
* case WM_CLOSE
*---------------------------------------------------------------------*/
  case WM_CLOSE:
    PostQuitMessage(0);
  return 0;

/*----------------------------------------------------------------------
* case WM_DESTROY
*---------------------------------------------------------------------*/
  case WM_DESTROY:
    PostQuitMessage(0);
  return 0;

  default:
    return DefWindowProc(hWnd, Message, wParam, lParam);
  } 
}
