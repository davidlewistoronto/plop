//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("gui_plop.res");
USEFORM("MeshEdit.cpp", CellEditForm);
USEFORM("AutoCell.cpp", AutoCellForm);
USEFORM("About.cpp", AboutBox);
USEFORM("Run.cpp", RunForm);
USEUNIT("NumEdit.cpp");
USEFORM("Picture.cpp", PictureForm);
USEFORM("MeshPicture.cpp", MeshPictureForm);
USEFORM("SupportPicture.cpp", SupportPictureForm);
USEFORM("ContourPicture.cpp", ContourPictureForm);
USEFORM("ColorPicture.cpp", ColorPictureForm);
USEUNIT("..\plate.cpp");
USEUNIT("..\grid_gen.cpp");
USEUNIT("..\gd.cpp");
USEUNIT("..\plot.cpp");
USEUNIT("..\sparsemat.cpp");
USEUNIT("..\plate_global.cpp");
USEUNIT("PlopExec.cpp");
USEFORM("GraphOptions.cpp", GraphOptionsForm);
USEUNIT("TCEdit.cpp");
USEFORM("PlopExecDone.cpp", RunFinishedForm);
USEFORM("Debug.cpp", DebugForm);
USEFORM("CellPartPicture.cpp", CellPartPictureForm);
USEFORM("PartDimension.cpp", PartDimensionForm);
USEUNIT("..\plop_parser.cpp");
USEUNIT("..\plop_debug.cpp");
USEUNIT("..\plop_run.cpp");
USEFORM("QuadPicture.cpp", QuadPictureForm);
USEFORM("Z88ColorPicture.cpp", Z88ColorPictureForm);
USEFORM("WhatsNew.cpp", WhatsNewForm);
//---------------------------------------------------------------------------
#include <stdio.h>
LPSTR GuiPlopArgs;

//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR MyArgs, int)
{   

	GuiPlopArgs = MyArgs;

	try
    {
        Application->Initialize();
		Application->HelpFile = "";
		Application->CreateForm(__classid(TCellEditForm), &CellEditForm);
		Application->CreateForm(__classid(TCellPartPictureForm), &CellPartPictureForm);
		Application->CreateForm(__classid(TMeshPictureForm), &MeshPictureForm);
		Application->CreateForm(__classid(TSupportPictureForm), &SupportPictureForm);
		Application->CreateForm(__classid(TContourPictureForm), &ContourPictureForm);
		Application->CreateForm(__classid(TColorPictureForm), &ColorPictureForm);
		Application->CreateForm(__classid(TPartDimensionForm), &PartDimensionForm);
		Application->CreateForm(__classid(TQuadPictureForm), &QuadPictureForm);
		Application->CreateForm(__classid(TZ88ColorPictureForm), &Z88ColorPictureForm);
		Application->CreateForm(__classid(TPictureForm), &PictureForm);
		Application->CreateForm(__classid(TAutoCellForm), &AutoCellForm);
		Application->CreateForm(__classid(TAboutBox), &AboutBox);
		Application->CreateForm(__classid(TGraphOptionsForm), &GraphOptionsForm);
		Application->CreateForm(__classid(TRunForm), &RunForm);
		Application->CreateForm(__classid(TRunFinishedForm), &RunFinishedForm);
		Application->CreateForm(__classid(TDebugForm), &DebugForm);
		Application->CreateForm(__classid(TWhatsNewForm), &WhatsNewForm);
		Application->Run();
    }
    catch (Exception &exception)
    {
        Application->ShowException(&exception);
	}

    return 0;
}

