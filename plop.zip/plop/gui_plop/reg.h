#ifndef regH
#define regH
void read_reg_val (char *key, char *subkey, char *val);
#endif

