//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "RunOptions.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TRunOptionsForm *RunOptionsForm;
//---------------------------------------------------------------------------
__fastcall TRunOptionsForm::TRunOptionsForm(TComponent* Owner)
    : TForm(Owner)
{
}
//---------------------------------------------------------------------------



