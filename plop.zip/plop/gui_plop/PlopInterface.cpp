//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "PlopInterface.h"
#include "MeshEdit.h"
#include "global.h"

#include <stdio.h>


//---------------------------------------------------------------------------
#pragma package(smart_init)




