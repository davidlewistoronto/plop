doing a scan var on r1 as outer radiuus causes double printing of r1=.54 and skips 0.55
