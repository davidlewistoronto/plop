#define xdcl_once extern
#include "plate_global.cpp"