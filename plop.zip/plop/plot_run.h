
#ifndef plot_run_h
#define plot_run_h

void 	interpolate_tris (void);


#endif

 